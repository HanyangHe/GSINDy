function dXN=NormalDrectionCorrect_TorusConstW_Ideal(t,X,R,r,dw_theta)

x=real(X(1,1));
y=real(X(2,1));

phi=atan2(y,x);

x_secCenter=R*cos(phi);
y_secCenter=R*sin(phi);
z_secCenter=0;

P=[x_secCenter;y_secCenter;z_secCenter];

[~,N]=TNspace_TorusConstW_Ideal(X, R, r);
n=N;

if n'*(P-X)>0
n=n;
else
n=-n;
end

dXN=abs(r-r*cos(dw_theta))*n;

function [T,N]=TNspace_TorusConstW_Ideal(X, R, r)
% v1*x1+v2*x2+v3*x3=0

x=real(X(1,1));
y=real(X(2,1));
z=real(X(3,1));

[phi, theta] = xyzToUv(x, y, z, R, r);

% tangent vector
Tphi = [-(R + r * cos(theta)) * sin(phi); (R + r * cos(theta)) * cos(phi); 0];
Ttheta = [-r * sin(theta) * cos(phi); -r * sin(theta) * sin(phi); r * cos(theta)];
    
% normal vector
N = cross(Tphi, Ttheta);
    
% normalize
Tphi=Tphi/norm(Tphi);
Ttheta=Ttheta/norm(Ttheta);
T=[Tphi Ttheta];
N = N / norm(N);

function [u, v] = xyzToUv(x, y, z, R, r)
    % calculate u
    u = atan2(y, x); % belong to [-pi, pi]
    if u < 0
        u = u + 2 * pi; % trans u to [0, 2*pi)
    end
    
    % calculate v
    sin_v = real(z / r);
    cos_v = real(sqrt(1 - sin_v^2)); % as sin^2(v) + cos^2(v) = 1
    v = atan2(sin_v, cos_v); % use atan2 make sure v in right quadrant
    
    % correct value of v, make sure (R + r*cos(v)) is coinside with the
    % result of x,y
    projected_R = sqrt(x^2 + y^2);
    calculated_R = R + r * cos(v);
    if abs(projected_R - calculated_R) > 0.1 * r % tolerance is the 10% of tube radius r
        v = 2 * pi - v; % if not match, then v is in another half cycle
    end
end
end

end