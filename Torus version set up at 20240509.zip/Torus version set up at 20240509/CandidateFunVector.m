function lib=CandidateFunVector(t,X,X0,n,polyorder,usesine)

lib=[];

% =======step 1: test frequency sweeping=========
% for k=1:100
%     w=k/10;
%     lib=[lib sin(w*t) cos(w*t)];
% end

lib=[lib poolData(X,n,polyorder,usesine)];

% ========step2: test new candidate function idea (fixed initial point)======
% 
% w_phi=0.2;
% w_theta=2;
% 
% lib=[sin((w_phi+w_theta)*t) sin((w_phi-w_theta)*t) cos((w_phi+w_theta)*t) cos((w_phi-w_theta)*t) sin(w_phi*t) cos(w_phi*t) sin(w_theta*t) cos(w_theta*t)];
%[sin(0.2t) cos(0.2t) sin(1.8t) cos(1.8t) sin(2t) cos(2t) sin(2.2t) cos(2.2t)]

% =========step3: test frequency sweeping with new candidate function (fixed initial point)====

% given exact truth frequency terms
% for k=[2 18 20 22]
%     w=k/10;
%     lib=[lib sin(w*t) cos(w*t)];
% end

% sweeping more terms
% for k=[2 18 20 22 1 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 19 21 23 24 25]
%     w=k/10;
%     lib=[lib sin(w*t) cos(w*t)];
% end

% for k=1:100
%     w=k/10;
%     lib=[lib sin(w*t) cos(w*t)];
% end

% ==========step4: test frequency sweeping with new candidate function (flexible initial point)====

% given exact truth frequency terms
% for k=[2 18 20 22]
%     w=k/10;
%     lib=[lib poolData(X0,n,polyorder,usesine)*sin(w*t) poolData(X0,n,polyorder,usesine)*cos(w*t)];
% end