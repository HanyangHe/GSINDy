function dotAngle=torusDynamics_SphereCoor(t,Angle,wu,wv)

dotAngle=[wu;wv];