function [eOffTorus,P]=OffTorusError(X,R,r)

x=X(1,1);
y=X(2,1);

phi=atan2(y,x);

x_secCenter=R*cos(phi);
y_secCenter=R*sin(phi);
z_secCenter=0;

P=[x_secCenter;y_secCenter;z_secCenter];

real_r=norm(X-P);
eOffTorus=norm(real_r-r);