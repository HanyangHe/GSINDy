clear all,


%%% align tangent vectors
%%% 2D torus

%% given manifold parameters for 2D torus

%%% manifold parameter
d = 2;
n = 3;
Ntheta = 2^5;

for j= 1:5

    Nphi = 2^(j+4);
    N = Ntheta*Nphi; % total # of points on manifold
    % extrinsic data
    am = 2;   % a > 1 radius of larger circle
    %%% 1 == well-sampled data
    %%% 2 == random data
    DATA_INDEX = 2;
    k = ceil(sqrt(N));
    degr = 4;
    
%%% generate data
    [x,theta] = torus_generate(DATA_INDEX,am,Ntheta,Nphi);

    % different way to calculate the tangent space, by the way the projection matrix
    [Ptrue,tvec] = torus_P0Cheat(theta,x,am);
    [Phat,tvec_hat] = localPCA(x,k,d,n);% tradictional svd method
    [Ptilde,tvec_tilde] = gmls_localPCA(x,k,d,n,degr);% first order correction gmls method
    
    [Ptilde2,tvec,dx] = gmls_localPCA_1pt(x,k,d,n,degr,x(200,:));

    dx2 = .05*tvec(:,1)' +.03*tvec(:,2)'
    x2 = x(200,:) + dx2;% the projection point of the next point on the tangent space
    [iota] = GMLSparam(dx,tvec,degr,d,x(200,:),x2);%iota is the next terminal point
    dx2hat = Ptilde2*(iota-x(200,:))'
    norm(dx2' - dx2hat)

    xplot(j) = N;
    Errorhat(j) =mean(pagenorm(permute(Ptrue - Phat,[3,2,1]),'fro'));
    Errortilde(j) =mean(pagenorm(permute(Ptrue - Ptilde,[3,2,1]),'fro'));
end

loglog(xplot,Errorhat,'r',xplot,Errortilde,'b')