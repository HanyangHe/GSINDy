function [iota] = GMLSparam(dx,U,degr,d,x0,x1)

% construct a local chart
lcx = dx*U;%U is the tensor of T*T'  = zeros(d,n,N);

k0 = size(dx,1);
n = size(dx,2);
if d > 1
    index =  generatemultiindex(degr,d); % index is d*term
else
    index = 0:1:degr;
end
term = size(index,2);

Phi = ones(k0,term);
for ss = 1:term
    for rr = 1:d
        Phi(:,ss) = Phi(:,ss).*lcx(:,rr).^index(rr,ss);
    end    
end
a1 = pinv(Phi'*Phi,1e-8) * Phi'*lcx(:,n);

dx2 = x1-x0;
tlcx = dx2*U;

Phi1 = ones(1,term); % k*term
for ss = 1:term
    for rr = 1:d
        Phi1(1,ss) = Phi1(1,ss).*tlcx(rr).^index(rr,ss);
    end
end
iota = tlcx(1)* U(:,1)' + tlcx(2)*U(:,2)' +  Phi1*a1 * U(:,3)' + x0;


end