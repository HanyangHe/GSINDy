function [P0_tilde,tvec_tilde2] = localPCA(x,k,d,n,degr)

%%% Inputs
    %%% x       - N-by-[n_R] data set with N data points in R^n_R
    %%% k       - number of nearest neighbors to use
    %%% d       - intrinsic dimension, must be integer
    %%% n       - ambient dimension
    %%% degr    - degree of polynomial used
        
%%% Outputs
    %%% P0_tilde   - Tangential projection matrix, N*n*n
   
% %%% Weight function with parameter
% % weight = @(d,D) (1-d/D)^4*((4*d)/D + 1);
% % weight = @(d,D) exp(-D^2*d^2);
% weight = @(d,D) 1;
% % weight = @(d,D) max((1-d/D)^4,0);
% Interval_para = 1;

N = size(x,1); 

if d > n % d <= n
    disp('d must be <= n');
    return;
end
if d == n
    P0_tilde = zeros(n,n,N);  
    for i = 1:N
        P0_tilde(:,:,i) = eye(n);
    end
    return;
end
%minterm = nchoosek(degr+d,d);

if k <= d % k > d
    disp(['k must be > ' num2str(d)]);
    return;
end

%%% k nearest neighbors
[~,inds] = knnCPU(x,x,k); % N*k

%% local SVD 

P0_tilde = zeros(n,n,N);    
tvec_tilde = zeros(d,n,N); % tvec is d*n*N
tvec_tilde2 = zeros(d,n,N); % tvec is d*n*N

for i = 1:N
    
    temp = x(inds(i,:),:)'; % n*k
    tempmean = mean(temp,2); % n*1
    temp_rough = temp - repmat(tempmean,1,k); % n*k
    
    [U,S,~] = svd(temp_rough);
    [~,IX] = sort(diag(S),'descend');
    U = U(:,IX); % rotation matrix
    
    %%% rough tangent space for representation of geodesic normal
    %%% coordiante
    t_rough = U(:,1:d); % n*d
    n_rough = U(:,d+1:n); % n*(n-d)
    tvec_tilde(:,:,i) = t_rough'; % tvec is d*n*N
    
    
    %%% generate projection matrix by tangent vectors
    P0_tilde(:,:,i) = tvec_tilde(:,:,i)'*pinv(tvec_tilde(:,:,i)*tvec_tilde(:,:,i)')*tvec_tilde(:,:,i);
    %%% generate orthonormal tangent vectors by projection matrix
    [U2,S2,~] = svd(P0_tilde(:,:,i));
    [~,IX2] = sort(diag(S2),'descend');
    U2 = U2(:,IX2); % eigenvector
    tvec_tilde2(:,:,i) = U2(:,1:d)'; % tvec is d*n*N
   
end

P0_tilde = permute(P0_tilde,[3,2,1]); % P0 is N*n*n

    
end



