function lib=CandidateFunVectorIdeal(t,Xi,R,r,w_theta,theta0,w_phi,phi0,mode)

if mode==1
x=Xi(1,1);
y=Xi(2,1);
z=Xi(3,1);

K=sqrt(r^2-z^2);
KK=1/(R+K);

lib=[1 x y y*z*KK x*z*KK K cos(w_theta*t+theta0)];

elseif mode==2
lib=[cos(w_phi*t+phi0)*sin(w_theta*t+theta0) sin(w_phi*t+phi0)*cos(w_theta*t+theta0) sin(w_phi*t+phi0) sin(w_phi*t+phi0)*sin(w_theta*t+theta0) cos(w_phi*t+phi0)*cos(w_theta*t+theta0) cos(w_phi*t+phi0) cos(w_theta*t+theta0)];
else
    disp('mode error');
end