function dotX=torusDynamics_RecCoor(t,X,w_phi,w_theta,phi0,theta0,r,R)

% ===== This version is right but will drop to a equilibrium point dotz=0 ====
% x=X(1,1);
% y=X(2,1);
% z=X(3,1);
% dotx=-w_theta*x*z/(R+sqrt(r^2-z^2))-w_phi*y;
% doty=-w_theta*y*z/(R+sqrt(r^2-z^2))+w_phi*x;
% dotz=w_theta*sqrt(r^2-z^2);

% ===== This version is based on higher order state - second order - speed ======
% x=X(1,1);
% y=X(2,1);
% z=X(3,1);
% vx=X(4,1);
% vy=X(5,1);
% vz=X(6,1);% in this case, ideal vz=w_theta*sin(w*t);w=2*pi/T;T=t_total/10;t_total=31.42;
% 
% K=sqrt(r^2-z^2);
% 
% dotx=vx;%vx=R*w_phi*cos(w_phi*t)
% doty=vy;%vy=R*w_phi*sin(w_phi*t)
% dotz=vz;%vz=r*w_theta*cos(w_theta*t)
% dotvx=-w_theta*z*vx/(R+K)-w_phi*vy-w_theta*x*vz/(R+K)-w_theta*x*z^2*vz/(K*(R+K)^2);
% dotvy=-w_phi*vx-w_theta*z*vy/(R+K)-w_theta*y*vz/(R+K)-w_theta*y*z^2*vz/(K*(R+K)^2);
% dotvz=-w_theta*z*vz/K;
% 
% dotX=[dotx;doty;dotz;dotvx;dotvy;dotvz];


% ===========mixed version solved the dotz=0 problem (vz use sphere coor)=============
% x=X(1,1);
% y=X(2,1);
% z=X(3,1);

% dotx=-w_theta*x*z/(R+sqrt(r^2-z^2))-w_phi*y;
% doty=-w_theta*y*z/(R+sqrt(r^2-z^2))+w_phi*x;

dotx=-r*w_theta*cos(w_phi*t+phi0)*sin(w_theta*t+theta0)-r*w_phi*sin(w_phi*t+phi0)*cos(w_theta*t+theta0)-R*w_phi*sin(w_phi*t+phi0);
doty=-r*w_theta*sin(w_phi*t+phi0)*sin(w_theta*t+theta0)+r*w_phi*cos(w_phi*t+phi0)*cos(w_theta*t+theta0)+R*w_phi*cos(w_phi*t+phi0);
dotz=r*w_theta*cos(w_theta*t+theta0);

dotX=[dotx;doty;dotz];
% dotX=[dotx;doty;dotz;dotvz];
