function dotX=GSINDySysModelwithNormCorrect(t,X,R,r,w_theta,w_phi,Dt,Coef_IdlGeomSINDy,theta0)

X=real(X);

dotXT=(CandidateFunVectorIdeal(t,X,R,r,w_theta,theta0)*Coef_IdlGeomSINDy)';
dXT=dotXT*Dt;

dtheta=w_theta*Dt;
dphi=w_phi*Dt;
dXN_mag=sqrt(norm(dXT)^2-(R*dphi)^2)*tan(pi/2-(pi-dtheta)/2);
[~,N]=TNspace_TorusConstW_Ideal(X, R, r);
[~,P]=OffTorusError(X,R,r);
if N'*(P-X)<0
N=-N;
end
dXN=dXN_mag*N;
dotXN=dXN/Dt;

dotX=dotXT+dotXN;

% dotX=dotXT;