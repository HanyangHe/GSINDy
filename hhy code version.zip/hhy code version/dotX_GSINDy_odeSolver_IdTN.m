function dotX=dotX_GSINDy_odeSolver_IdTN(t,X,n,polyorder,usesine,Coef_GeomSINDy, R, r,useProj)

dotX=(CandidateFunVectorOriPolySine(t,X',n,polyorder,usesine)*Coef_GeomSINDy)';

if useProj==1
[Ti,~]=TNspace_Torus_Ideal(X, R, r);
Pi=Ti*pinv(Ti'*Ti)*Ti';
dotX=Pi*dotX;
end