function [eOffTorus,P]=OffTorusError(X,R,r)
%X is n-by-N; n is ambient dimension, N is number of points
x=X(1,:);
y=X(2,:);

phi=atan2(y,x);

x_secCenter=R*cos(phi);
y_secCenter=R*sin(phi);
z_secCenter=zeros(size(phi));

P=[x_secCenter;y_secCenter;z_secCenter];

real_r=vecnorm(X-P);
eOffTorus=abs(real_r-r*ones(size(real_r)))./r;