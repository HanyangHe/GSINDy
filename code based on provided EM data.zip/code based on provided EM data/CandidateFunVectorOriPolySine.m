function lib=CandidateFunVectorOriPolySine(t,X,n,polyorder,usesine)

lib=[];

lib=[lib poolData(X,n,polyorder,usesine)];