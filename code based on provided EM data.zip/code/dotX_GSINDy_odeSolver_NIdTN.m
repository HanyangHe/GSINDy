function dotX=dotX_GSINDy_odeSolver_NIdTN(t,X,n,polyorder,usesine,Coef_GeomSINDy,searchPool,knear,d,degr,index,useProjection)
% 
% persistent firstCall
% global currentStepTime;
% 
% if mod(t,Dt)==0
%     firstCall = true;
%     % currentStepTime = t;
% end
% 
% if firstCall
dotX=(CandidateFunVectorOriPolySine(t,X',n,polyorder,usesine)*Coef_GeomSINDy)';

if useProjection==1
    [Ti,~,~]=TNspace_Torus(searchPool',knear,d,n,degr,index,X');
    Pi=Ti*pinv(Ti'*Ti)*Ti';
    dotX=Pi*dotX;
end
% firstCall = false;
% else
% dotX=(CandidateFunVectorOriPolySine(t,X',n,polyorder,usesine)*Coef_GeomSINDy)';
% end